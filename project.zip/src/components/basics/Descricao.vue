<template lang="pug">
  p: slot
</template>

<style lang="scss" scoped>

</style>

<script>

</script>
