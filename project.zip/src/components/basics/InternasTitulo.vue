<template lang="pug">
  span.titulo: slot
</template>

<style lang="scss" scoped>

  .titulo {
    font-size: 30px;
    font-weight: bold;
  }

</style>

<script>

</script>
