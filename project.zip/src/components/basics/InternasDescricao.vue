<template lang="pug">
  p.descricao: slot
</template>

<style lang="scss" scoped>

 p {
   margin: 0;
 }

 .descricao {
   margin: 15px 0;
 }

</style>

<script>

</script>
